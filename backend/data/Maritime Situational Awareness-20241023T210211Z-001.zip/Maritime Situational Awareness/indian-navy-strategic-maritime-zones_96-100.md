96. ```json
    {
      "name": "Daman-Diu Coastal Security Corridor",
      "type": "Integrated Coastal Surveillance Zone",
      "significance": "Monitoring of maritime activities in Union Territories",
      "coordinates": [
        {"lat": 20.0, "lon": 72.5},
        {"lat": 20.0, "lon": 73.0},
        {"lat": 21.0, "lon": 73.0},
        {"lat": 21.0, "lon": 72.5}
      ]
    }
    ```

97. ```json
    {
      "name": "Bhitarkanika Mangrove Maritime Eco-Security Zone",
      "type": "Environmental Protection and Security Area",
      "significance": "Biodiversity conservation and anti-poaching operations",
      "coordinates": [
        {"lat": 20.5, "lon": 86.5},
        {"lat": 20.5, "lon": 87.5},
        {"lat": 21.0, "lon": 87.5},
        {"lat": 21.0, "lon": 86.5}
      ]
    }
    ```

98. ```json
    {
      "name": "Vizag Submarine Communication Test Range",
      "type": "Underwater Communications Evaluation Area",
      "significance": "Testing and development of submarine communication systems",
      "coordinates": [
        {"lat": 17.0, "lon": 83.0},
        {"lat": 17.0, "lon": 84.0},
        {"lat": 18.0, "lon": 84.0},
        {"lat": 18.0, "lon": 83.0}
      ]
    }
    ```

99. ```json
    {
      "name": "Andaman Sea Humanitarian Assistance and Disaster Relief Staging Area",
      "type": "HADR Preparedness Zone",
      "significance": "Prepositioning for rapid response to natural disasters",
      "coordinates": [
        {"lat": 11.0, "lon": 92.0},
        {"lat": 11.0, "lon": 94.0},
        {"lat": 13.0, "lon": 94.0},
        {"lat": 13.0, "lon": 92.0}
      ]
    }
    ```

100. ```json
     {
       "name": "Lakshadweep-Malabar Coast Integrated Maritime Surveillance Sector",
       "type": "Extended Maritime Domain Awareness Zone",
       "significance": "Comprehensive monitoring of approaches to southwest coast",
       "coordinates": [
         {"lat": 8.0, "lon": 72.0},
         {"lat": 8.0, "lon": 76.0},
         {"lat": 14.0, "lon": 76.0},
         {"lat": 14.0, "lon": 72.0}
       ]
     }
     ```

